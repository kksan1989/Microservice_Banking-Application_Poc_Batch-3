package com.bank.DTOservice;

public class Saving {

	private static final long serialVersionUID = 1L;
	Integer savingId;

	String savingName;

	String features;

	String savingType;

	String elibigility;

	double interestRate;

	String emailStatement;

	String serviceCharges;

	String bankName;

	public Saving() {
	}

	public Integer getSavingId() {
		return savingId;
	}

	public void setSavingId(Integer savingId) {
		this.savingId = savingId;
	}

	public String getSavingName() {
		return savingName;
	}

	public void setSavingName(String savingName) {
		this.savingName = savingName;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public String getSavingType() {
		return savingType;
	}

	public void setSavingType(String savingType) {
		this.savingType = savingType;
	}

	public String getElibigility() {
		return elibigility;
	}

	public void setElibigility(String elibigility) {
		this.elibigility = elibigility;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getEmailStatement() {
		return emailStatement;
	}

	public void setEmailStatement(String emailStatement) {
		this.emailStatement = emailStatement;
	}

	public String getServiceCharges() {
		return serviceCharges;
	}

	public void setServiceCharges(String serviceCharges) {
		this.serviceCharges = serviceCharges;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Override
	public String toString() {
		return "Saving [savingId=" + savingId + ", savingName=" + savingName + ", features=" + features
				+ ", savingType=" + savingType + ", elibigility=" + elibigility + ", interestRate=" + interestRate
				+ ", emailStatement=" + emailStatement + ", serviceCharges=" + serviceCharges + ", bankName=" + bankName
				+ "]";
	}

}
