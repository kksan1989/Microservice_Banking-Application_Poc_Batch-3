package com.bank.apizuulservice;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.bank.DTOservice.Business;
import com.bank.DTOservice.Cards;
import com.bank.DTOservice.Corporate;
import com.bank.DTOservice.Employee;
import com.bank.DTOservice.Internet_Banking;
import com.bank.DTOservice.Loan;
import com.bank.DTOservice.Product;
import com.bank.DTOservice.Saving;
import com.bank.DTOservice.Student;

@Controller
public class ZuulController {

	@Autowired
	OAuth2RestTemplate restTemplate;

	@Value("${product.micro.api:http://localhost:8087/bank/products}")
	String productApi;

	@Value("${loan.micro.api:http://localhost:8089/bank/loan}")
	String loanApi;

	@Value("${cards.micro.api:http://localhost:8083/bank/cards}")
	String cardsApi;

	@Value("${corporate.micro.api:http://localhost:8088/bank/corporate}")
	String corporateApi;

	@Value("${internet.micro.api:http://localhost:8084/bank/internet-banking}")
	String internetApi;

	@Value("${saving.micro.api:http://localhost:8086/bank/saving}")
	String savingApi;

	@Value("${business.micro.api:http://localhost:8082/bank/business}")
	String businessApi;

	@Value("${employee.micro.api:http://localhost:8081/bank/employee}")
	String employeeApi;

	@Value("${student.micro.api:http://localhost:8085/bank/student}")
	String studentApi;

	@Autowired
	Loan loan;

	@Autowired
	Product product;

	@Autowired
	Cards cards;

	@Autowired
	Corporate corporate;

	@Autowired
	Internet_Banking internetBanking;

	@Autowired
	Saving saving;

	@Autowired
	Business business;

	@Autowired
	Employee employee;

	@Autowired
	Student student;

	@GetMapping("/product")
	public String productIndex(Model model) {
		ResponseEntity<Product[]> productResp = restTemplate.getForEntity(productApi, Product[].class);
		List<Product> productDTOS = Arrays.asList(productResp.getBody());

		model.addAttribute("products", productDTOS);

		return "product";
	}

	@GetMapping("/loan")
	public String loanIndex(Model model) {

		ResponseEntity<Loan[]> loanResp = restTemplate.getForEntity(loanApi, Loan[].class);
		List<Loan> loanData = Arrays.asList(loanResp.getBody());

		model.addAttribute("Loans", loanData);

		return "loanApi";
	}

	@GetMapping("/cards")
	public String cardsIndex(Model model) {

		ResponseEntity<Cards[]> cardsResp = restTemplate.getForEntity(cardsApi, Cards[].class);
		List<Cards> cardData = Arrays.asList(cardsResp.getBody());

		model.addAttribute("cards", cardData);

		return "cardsApi";
	}

	@GetMapping("/corporate")
	public String coporateIndex(Model model) {

		ResponseEntity<Corporate[]> corporateResp = restTemplate.getForEntity(corporateApi, Corporate[].class);
		List<Corporate> coporateData = Arrays.asList(corporateResp.getBody());

		model.addAttribute("corporate", coporateData);

		return "corporateApi";
	}
	

	@GetMapping("/internetBanking")
	public String internetBankingIndex(Model model) {

		ResponseEntity<Internet_Banking[]> internetResp = restTemplate.getForEntity(internetApi, Internet_Banking[].class);
		List<Internet_Banking> internetData = Arrays.asList(internetResp.getBody());

		model.addAttribute("internetBanking", internetData);

		return "internetBanking";
	}

	@GetMapping("/saving")
	public String savingIndex(Model model) {

		ResponseEntity<Saving[]> savingResp = restTemplate.getForEntity(savingApi, Saving[].class);
		List<Saving> savingData = Arrays.asList(savingResp.getBody());

		model.addAttribute("saving", savingData);

		return "saving";
	}

	@GetMapping("/student")
	public String studentIndex(Model model) {

		ResponseEntity<Student[]> studentResp = restTemplate.getForEntity(studentApi, Student[].class);
		List<Student> studentData = Arrays.asList(studentResp.getBody());

		model.addAttribute("student", studentData);

		return "student";
	}

	@GetMapping("/employee")
	public String enplyeeIndex(Model model) {

		ResponseEntity<Employee[]> employeeResp = restTemplate.getForEntity(employeeApi, Employee[].class);
		List<Employee> employeeData = Arrays.asList(employeeResp.getBody());

		model.addAttribute("employee", employeeData);

		return "employee";
	}
	
	@GetMapping("/business")
	public String businessIndex(Model model) {

		ResponseEntity<Business[]> businessResp = restTemplate.getForEntity(businessApi, Business[].class);
		List<Business> businessData = Arrays.asList(businessResp.getBody());

		model.addAttribute("business", businessData);

		return "business";
	}
}
