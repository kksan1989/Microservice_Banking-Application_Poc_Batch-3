package com.bank.DTOservice;

public class Business {

	private static final long serialVersionUID = 1L;
	Integer businessId;

	String businessName;

	String address;

	int mobileNo;

	String emailAddress;

	String bank;

	public Business() {
	}

	public Integer getBusinessId() {
		return businessId;
	}

	public void setBusinessId(Integer businessId) {
		this.businessId = businessId;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Business [businessId=" + businessId + ", businessName=" + businessName + ", address=" + address
				+ ", mobileNo=" + mobileNo + ", emailAddress=" + emailAddress + ", bank=" + bank + "]";
	}

}
