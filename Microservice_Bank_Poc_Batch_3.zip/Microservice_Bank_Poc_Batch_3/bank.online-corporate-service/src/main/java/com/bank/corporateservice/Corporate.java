package com.bank.corporateservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "CORPORATE")
@Entity
public class Corporate {

	private static final long serialVersionUID = 1L;
	@Id // Pk
	@Column(name = "CORPORATEID")
	int corporateId;

	@Column(name = "CORPORATENAME")
	String corporateName;
	
	@Column(name = "CORPORATETYPE")
	String corporateType;

	@Column(name = "ADDRESS")
	String address;


	@Column(name = "EMAIL")
	String emailAddress;

	@Column(name = "BANK")
	String bank;

	public Corporate() {
	}

	public Corporate(int corporateId, String corporateName, String address, String emailAddress, String bank) {
		super();
		this.corporateId = corporateId;
		this.corporateName = corporateName;
		this.address = address;
		this.emailAddress = emailAddress;
		this.bank = bank;
	}

	public int getCorporateId() {
		return corporateId;
	}

	public void setCorporateId(int corporateId) {
		this.corporateId = corporateId;
	}

	public String getCorporateName() {
		return corporateName;
	}

	public void setCorporateName(String corporateName) {
		this.corporateName = corporateName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	public String getCorporateType() {
		return corporateType;
	}

	public void setCorporateType(String corporateType) {
		this.corporateType = corporateType;
	}

	@Override
	public String toString() {
		return "Corporate [corporateId=" + corporateId + ", corporateName=" + corporateName + ", corporateType="
				+ corporateType + ", address=" + address + ", emailAddress=" + emailAddress + ", bank=" + bank + "]";
	}
	
}
