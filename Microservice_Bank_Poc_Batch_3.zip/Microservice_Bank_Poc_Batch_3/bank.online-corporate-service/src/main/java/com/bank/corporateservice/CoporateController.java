package com.bank.corporateservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class CoporateController {

    @Autowired
    private CoporateRepository coporateRepository;

    @PostMapping(value = "/corporate")
    public Corporate save (@RequestBody Corporate corporate){
        return coporateRepository.save(corporate);
    }

    @GetMapping(value = "/corporate")
    public Iterable<Corporate> all (){
        return coporateRepository.findAll();
    }

    @GetMapping(value = "/corporate/{corporateId}")
    public Corporate findByCorporateId (@PathVariable Integer corId){
        return coporateRepository.findCorporateByCorporateId(corId);
    }

    @PutMapping(value = "/corporate")
    public Corporate update (@RequestBody Corporate corporate){
        return coporateRepository.save(corporate);
    }

    @DeleteMapping(value = "/corporate")
    public void delete (@RequestBody Corporate corporate){
        coporateRepository.delete(corporate);
    }

    @GetMapping(value = "/corporate/corporate-type/{type}")
    public List<Corporate> findByemployeeType (@PathVariable String type){
	return coporateRepository.findAllByCorporateType(type);
    }
	
    @GetMapping(value = "/account/bank/{bank}")
    public List<Corporate> findByBank (@PathVariable String bank){
	return coporateRepository.findByBank(bank);
    }
	
    @GetMapping(value = "/account/corporate/{customer}")
    public List<Corporate> findByCutomer (@PathVariable Integer customer){
	return coporateRepository.findAllByCustomerId(customer);
    }

}
