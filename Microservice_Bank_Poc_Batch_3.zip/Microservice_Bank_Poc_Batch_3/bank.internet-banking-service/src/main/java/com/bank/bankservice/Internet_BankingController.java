package com.bank.bankservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class Internet_BankingController {

    @Autowired
    private Internet_BankingRepository internet_BankingRepository;

    @PostMapping(value = "/internetbanking")
    public Internet_Banking save (@RequestBody Internet_Banking banking){
        return internet_BankingRepository.save(banking);
    }

    @GetMapping(value = "/internetbanking")
    public Iterable<Internet_Banking> all (){
        return internet_BankingRepository.findAll();
    }

    @GetMapping(value = "/internetbanking/{internetbankingId}")
    public Internet_Banking findByAccountId (@PathVariable Integer bankingId){
        return internet_BankingRepository.findBankByBankingId(bankingId);
    }

    @PutMapping(value = "/internetbanking")
    public Internet_Banking update (@RequestBody Internet_Banking banking){
        return internet_BankingRepository.save(banking);
    }

    @DeleteMapping(value = "/internetbanking")
    public void delete (@RequestBody Internet_Banking banking){
        internet_BankingRepository.delete(banking);
    }

    @GetMapping(value = "/internetbanking/banking-type/{type}")
    public List<Internet_Banking> findByemployeeType (@PathVariable String type){
	return internet_BankingRepository.findAllByBankingType(type);
    }
	
    @GetMapping(value = "/account/internetbanking/{bank}")
    public List<Internet_Banking> findByBank (@PathVariable String bank){
	return internet_BankingRepository.findByBank(bank);
    }
	
    @GetMapping(value = "/account/customer/{customer}")
    public List<Internet_Banking> findByCutomer (@PathVariable Integer customer){
	return internet_BankingRepository.findAllByBankingId(customer);
    }

}
