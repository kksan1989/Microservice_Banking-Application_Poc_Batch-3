package com.bank.loanservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "LOAN")
@Entity
public class Loan {

	private static final long serialVersionUID = 1L;
	@Id // Pk
	@Column(name = "LOANID")
	Integer loanId;

	@Column(name = "LOANNAME")
	String loanName;

	@Column(name = "LOANTYPE")
	String loanType;

	@Column(name = "LOANAMMOUT")
	double loanAmmount;

	@Column(name = "BANK")
	String bank;

	public Loan() {
	}

	public Loan(Integer loanId, String loanName, String loanType, double loanAmmount, String bank) {
		super();
		this.loanId = loanId;
		this.loanName = loanName;
		this.loanType = loanType;
		this.loanAmmount = loanAmmount;
		this.bank = bank;
	}

	public Integer getLoanId() {
		return loanId;
	}

	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}

	public String getLoanName() {
		return loanName;
	}

	public void setLoanName(String loanName) {
		this.loanName = loanName;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public double getLoanAmmount() {
		return loanAmmount;
	}

	public void setLoanAmmount(double loanAmmount) {
		this.loanAmmount = loanAmmount;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Loan [loanId=" + loanId + ", loanName=" + loanName + ", loanType=" + loanType + ", loanAmmount="
				+ loanAmmount + ", bank=" + bank + "]";
	}


}
