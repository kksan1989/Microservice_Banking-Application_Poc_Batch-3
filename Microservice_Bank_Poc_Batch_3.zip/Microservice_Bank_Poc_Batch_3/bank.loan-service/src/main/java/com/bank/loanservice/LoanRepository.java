package com.bank.loanservice;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface LoanRepository extends CrudRepository<Loan, Integer> {

    Loan findLoanByLoanId(Integer customerId);

    List<Loan> findAllByLoanType(String accountType);

    List<Loan> findByBank(String bank);

    Loan findAllByLoanId(Integer accountId);

}
