package com.bank.studentservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @PostMapping(value = "/student")
    public Student save (@RequestBody Student student){
        return studentRepository.save(student);
    }

    @GetMapping(value = "/student")
    public Iterable<Student> all (){
        return studentRepository.findAll();
    }

    @GetMapping(value = "/student/{studId}")
    public Student findByAccountId (@PathVariable Integer empId){
        return studentRepository.findStudentByAccountId(empId);
    }

    @PutMapping(value = "/student")
    public Student update (@RequestBody Student student){
        return studentRepository.save(student);
    }

    @DeleteMapping(value = "/student")
    public void delete (@RequestBody Student student){
        studentRepository.delete(student);
    }

    @GetMapping(value = "/student/student-type/{type}")
    public List<Student> findByemployeeType (@PathVariable String type){
	return studentRepository.findAllByStudentType(type);
    }
	
    @GetMapping(value = "/student/bank/{bank}")
    public List<Student> findByBank (@PathVariable String bank){
	return studentRepository.findByBank(bank);
    }
	
    @GetMapping(value = "/account/customer/{customer}")
    public List<Student> findByCutomer (@PathVariable Integer customer){
	return studentRepository.findAllByCustomerId(customer);
    }

}
