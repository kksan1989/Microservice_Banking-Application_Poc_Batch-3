package com.bank.studentservice;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface StudentRepository extends CrudRepository<Student, Integer> {

    List<Student> findAllByCustomerId(Integer customerId);

    List<Student> findAllByStudentType(String accountType);

    List<Student> findByBank(String bank);

    Student findStudentByAccountId(Integer accountId);

}
