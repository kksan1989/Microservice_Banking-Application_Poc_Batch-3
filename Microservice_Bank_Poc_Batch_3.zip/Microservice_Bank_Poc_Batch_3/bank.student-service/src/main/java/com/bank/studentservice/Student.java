package com.bank.studentservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "STUDENT")
@Entity
public class Student {

	private static final long serialVersionUID = 1L;
	@Id // Pk
	@Column(name = "STUDID")
	Integer studId;

	@Column(name = "STUDNAME")
	String studName;

	@Column(name = "ADDRESS")
	String address;

	@Column(name = "MOBILENO")
	int mobileNo;

	@Column(name = "EMAIL")
	String emailAddress;

	@Column(name = "BANK")
	String bank;

	public Student() {
	}

	public Integer getStudId() {
		return studId;
	}

	public void setStudId(Integer studId) {
		this.studId = studId;
	}

	public String getStudName() {
		return studName;
	}

	public void setStudName(String studName) {
		this.studName = studName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getBank() {
		return bank;
	}

	public void setBank(String bank) {
		this.bank = bank;
	}

	@Override
	public String toString() {
		return "Student [studId=" + studId + ", studName=" + studName + ", address=" + address + ", mobileNo="
				+ mobileNo + ", emailAddress=" + emailAddress + ", bank=" + bank + "]";
	}


	
}
