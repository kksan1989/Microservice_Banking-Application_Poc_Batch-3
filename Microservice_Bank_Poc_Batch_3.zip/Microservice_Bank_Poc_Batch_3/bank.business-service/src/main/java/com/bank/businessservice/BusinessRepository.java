package com.bank.businessservice;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface BusinessRepository extends CrudRepository<Business, Integer> {

    List<Business> findAllByBusinessId(Integer businessId);

    List<Business> findAllByBusinessType(String accountType);

    List<Business> findByBank(String bank);

    Business findByBusinessId(Integer accountId);

}
