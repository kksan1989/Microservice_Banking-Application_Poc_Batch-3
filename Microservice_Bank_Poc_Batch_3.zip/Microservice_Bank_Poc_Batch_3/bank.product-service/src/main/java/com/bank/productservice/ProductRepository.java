package com.bank.productservice;

import org.springframework.data.repository.CrudRepository;

import java.util.List;
import java.util.Optional;

public interface ProductRepository extends CrudRepository<Product, Integer> {

    Product findAllByProductId(Integer productId);

    List<Product> findAllByProductType(String productType);

    List<Product> findByBank(String bank);

    Product findProductByProductId(Integer accountId);

}
