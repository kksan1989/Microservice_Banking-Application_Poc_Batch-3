package com.bank.savingservice;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "SAVING")
@Entity
public class Saving {

	private static final long serialVersionUID = 1L;
	@Id // Pk
	@Column(name = "SAVINGID")
	Integer savingId;

	@Column(name = "SAVINGNAME")
	String savingName;

	@Column(name = "FEATURES")
	String features;

	@Column(name = "SAVINGTYPE")
	String savingType;

	@Column(name = "ELIGIBILTY")
	String elibigility;

	@Column(name = "INTRESTRATE")
	double interestRate;

	@Column(name = "STATMENTBYEMAIL")
	String emailStatement;

	@Column(name = "SERVICECHAREGES")
	String serviceCharges;

	@Column(name = "BANKNAME")
	String bankName;

	public Saving() {
	}

	public Integer getSavingId() {
		return savingId;
	}

	public void setSavingId(Integer savingId) {
		this.savingId = savingId;
	}

	public String getSavingName() {
		return savingName;
	}

	public void setSavingName(String savingName) {
		this.savingName = savingName;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}

	public String getSavingType() {
		return savingType;
	}

	public void setSavingType(String savingType) {
		this.savingType = savingType;
	}

	public String getElibigility() {
		return elibigility;
	}

	public void setElibigility(String elibigility) {
		this.elibigility = elibigility;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getEmailStatement() {
		return emailStatement;
	}

	public void setEmailStatement(String emailStatement) {
		this.emailStatement = emailStatement;
	}

	public String getServiceCharges() {
		return serviceCharges;
	}

	public void setServiceCharges(String serviceCharges) {
		this.serviceCharges = serviceCharges;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	@Override
	public String toString() {
		return "Saving [savingId=" + savingId + ", savingName=" + savingName + ", features=" + features
				+ ", savingType=" + savingType + ", elibigility=" + elibigility + ", interestRate=" + interestRate
				+ ", emailStatement=" + emailStatement + ", serviceCharges=" + serviceCharges + ", bankName=" + bankName
				+ "]";
	}

}
